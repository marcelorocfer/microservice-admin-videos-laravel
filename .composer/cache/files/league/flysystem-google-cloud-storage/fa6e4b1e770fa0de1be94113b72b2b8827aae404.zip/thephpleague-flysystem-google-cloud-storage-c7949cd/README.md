## Sub-split of Flysystem for Google Cloud Storage (GCS).

> ⚠️ this is a sub-split, for pull requests and issues, visit: https://github.com/thephpleague/flysystem

```bash
composer require league/flysystem-google-cloud-storage
```

View the [documentation](https://flysystem.thephpleague.com/docs/adapter/google-cloud-storage/).
